sudo amazon-linux-extras install epel -y 
sudo yum install stress -y
stress -c 8