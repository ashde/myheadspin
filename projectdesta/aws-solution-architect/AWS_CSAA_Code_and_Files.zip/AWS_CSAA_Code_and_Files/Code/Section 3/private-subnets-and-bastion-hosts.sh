# Linux
ssh-add -c ec2-user@public-IP-address
# Mac
ssh-add -k ec2-user@public-IP-address
# Connect to private instance
 ssh -A ec2-user@private-IP-address